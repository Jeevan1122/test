import requests
import sseclient

def sse_testing():
    url = 'http://localhost:8190/sse'
    response = requests.get(url, stream=True)
    client = sseclient.SSEClient(response)

    for event in client.events():
        print(f"Received event: {event.data}")

sse_testing()


from mcp.server.fastmcp import FastMCP
from starlette.applications import Starlette
from mcp.server.sse import SseServerTransport
from starlette.requests import Request
from starlette.routing import Mount, Route
import uvicorn
import requests
import json
from uuid import uuid4
from starlette.responses import HTMLResponse
import os
import subprocess,tempfile
import requests
latest_scan_results = {}

mcp = FastMCP("Yottasecure")

# API_KEY = os.getenv("API_KEY")
from starlette.requests import Request
from starlette.responses import JSONResponse

async def scan_container(request: Request):
    global latest_scan_results
    data = await request.json()
    latest_scan_results = data
    return JSONResponse({"status": "success", "scanned_images": len(data.get("scans", []))})


async def get_scan_results(request: Request):
    if latest_scan_results:
        return JSONResponse(latest_scan_results)
    else:
        return JSONResponse({"status": "error", "message": "No scan results found."}, status_code=404)


@mcp.tool()
async def chatbot_api(agent_id: str, message: str) -> str:
    url = "http://34.29.244.78:3000/chatbot"
    payload = json.dumps({
        "agent_id": agent_id,
        "session_id": str(uuid4().hex),
        "message": message
    })
    headers = {
        'Content-Type': 'application/json',
        # 'Authorization': f"Bearer {API_KEY}"
    }
    response = requests.post(url, headers=headers, data=payload)
    return response.text

@mcp.tool()
async def scan_code(code: str) -> str:
    try:
        with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=True) as temp_file:
            temp_file.write(code)
            temp_file.flush()

            result = subprocess.run(
                ["bandit", "-r",temp_file.name,"json"],
                capture_output=True,
                text=True,
                check=True
            )

            return result.stdout if result.stdout.strip() else "No security issues found"

    except subprocess.CalledProcessError as e:
        return f"Bandit scan failed: {e.stderr or 'Unknown error (check bandit installation)'}"
    except Exception as e:
        return f"Unexpected error: {str(e)}"


@mcp.tool()
async def scan_docker_images(image: str) -> str:
    import subprocess
    try:
        result = subprocess.run(
            ["trivy", "image", "--scanners", "vuln", image],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout if result.stdout.strip() else "No vulnerabilities found."
    except subprocess.CalledProcessError as e:
        return f"Trivy scan failed: {e.stderr or 'Unknown error'}"
    except Exception as e:
        return f"Unexpected error: {str(e)}"
@mcp.tool()
def scan_results() -> dict:
    try:
        response = requests.get("http://0.0.0.0:8190/scan_results/")
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return {"status": "error", "message": str(e)}


async def homepage(request: Request) -> HTMLResponse:
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MCP Server</title>
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
            h1 {
                margin-bottom: 10px;
            }
            button {
                background-color: #f8f8f8;
                border: 1px solid #ccc;
                padding: 8px 16px;
                margin: 10px 0;
                cursor: pointer;
                border-radius: 4px;
            }
            button:hover {
                background-color: #e8e8e8;
            }
            .status {
                border: 1px solid #ccc;
                padding: 10px;
                min-height: 20px;
                margin-top: 10px;
                border-radius: 4px;
                color: #555;
            }
        </style>
    </head>
    <body>
        <h1>Yottasecure MCP Server</h1>

        <p>Server running!</p>

        <button id="connect-button">Connect to SSE</button>

        <div class="status" id="status">Connection status will appear here...</div>

        <script>
            document.getElementById('connect-button').addEventListener('click', function() {
                // Redirect to the SSE connection page or initiate the connection
                const statusDiv = document.getElementById('status');

                try {
                    const eventSource = new EventSource('/sse');

                    statusDiv.textContent = 'Connecting...';

                    eventSource.onopen = function() {
                        statusDiv.textContent = 'Connected to SSE';
                    };

                    eventSource.onerror = function() {
                        statusDiv.textContent = 'Error connecting to SSE';
                        eventSource.close();
                    };

                    eventSource.onmessage = function(event) {
                        statusDiv.textContent = 'Received: ' + event.data;
                    };

                    // Add a disconnect option
                    const disconnectButton = document.createElement('button');
                    disconnectButton.textContent = 'Disconnect';
                    disconnectButton.addEventListener('click', function() {
                        eventSource.close();
                        statusDiv.textContent = 'Disconnected';
                        this.remove();
                    });

                    document.body.appendChild(disconnectButton);

                } catch (e) {
                    statusDiv.textContent = 'Error: ' + e.message;
                }
            });
        </script>
    </body>
    </html>
    """
    return HTMLResponse(html_content)
from starlette.routing import Route, Mount

def create_app():
    sse = SseServerTransport("/messages/")

    async def handle_sse(request: Request):
        async with sse.connect_sse(request.scope, request.receive, request._send) as (read, write):
            await mcp._mcp_server.run(read, write, mcp._mcp_server.create_initialization_options())

    return Starlette(
        routes=[
            Route("/", endpoint=homepage),
            Route("/sse", endpoint=handle_sse),
            Mount("/messages/", app=sse.handle_post_message),
            Mount("/scan_images/", app=scan_docker_images),
            Mount("/scan_code/", app=scan_code),
            Route("/scan_results/", endpoint=scan_results, methods=["GET"]),

        ],
    )


if __name__ == "__main__":
    app = create_app()
    uvicorn.run(app, host="0.0.0.0", port=8190)
